﻿namespace CourseDesignPattern.Factory
{
    public interface IFactory
    {
        public void Speak();
    }
}
