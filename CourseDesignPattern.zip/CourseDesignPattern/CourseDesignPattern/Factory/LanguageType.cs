﻿namespace CourseDesignPattern.Factory
{
    public enum LanguageType
    {
        PT,
        EN
    }
}
