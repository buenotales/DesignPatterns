﻿namespace CourseDesignPattern.State
{
    public interface ICurrentState
    {
        public void Reprove(Budget budget);
        public void Approve(Budget budget);
        public void Finalize(Budget budget);
    }
}
