﻿using CourseDesignPattern.Factory;

namespace CourseDesignPattern.AbstractFactory
{
    public interface IAbstractFactory
    {
        public IFactory Instance();
    }
}
