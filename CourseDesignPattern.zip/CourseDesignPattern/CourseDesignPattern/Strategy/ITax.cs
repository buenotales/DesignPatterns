﻿namespace CourseDesignPattern
{
    public interface ITax
    {
        double Calculate(Budget budget);
    }
}
